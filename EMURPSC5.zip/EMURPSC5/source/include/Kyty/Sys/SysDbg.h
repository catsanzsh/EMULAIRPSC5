#ifndef INCLUDE_KYTY_SYS_SYSDBG_H_
#define INCLUDE_KYTY_SYS_SYSDBG_H_

#include "Kyty/Core/Common.h"

#include "Kyty/Sys/SysLinuxDbg.h" // IWYU pragma: export
#include "Kyty/Sys/SysWindowsDbg.h" // IWYU pragma: export

#endif /* INCLUDE_KYTY_SYS_SYSDBG_H_ */
