#ifndef INCLUDE_KYTY_SYS_SYSTIMER_H_
#define INCLUDE_KYTY_SYS_SYSTIMER_H_

#include "Kyty/Core/Common.h"

#include "Kyty/Sys/SysLinuxTimer.h" // IWYU pragma: export
#include "Kyty/Sys/SysWindowsTimer.h" // IWYU pragma: export

#endif /* INCLUDE_KYTY_SYS_SYSTIMER_H_ */
