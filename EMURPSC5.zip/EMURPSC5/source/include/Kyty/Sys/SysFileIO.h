#ifndef INCLUDE_KYTY_SYS_SYSFILEIO_H_
#define INCLUDE_KYTY_SYS_SYSFILEIO_H_

#include "Kyty/Core/Common.h"

#include "Kyty/Sys/SysLinuxFileIO.h" // IWYU pragma: export
#include "Kyty/Sys/SysWindowsFileIO.h" // IWYU pragma: export

#endif /* INCLUDE_KYTY_SYS_SYSFILEIO_H_ */
