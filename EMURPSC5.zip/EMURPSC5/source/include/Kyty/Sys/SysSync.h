#ifndef INCLUDE_KYTY_SYS_SYSSYNC_H_
#define INCLUDE_KYTY_SYS_SYSSYNC_H_

#include "Kyty/Core/Common.h"

#include "Kyty/Sys/SysLinuxSync.h" // IWYU pragma: export
#include "Kyty/Sys/SysWindowsSync.h" // IWYU pragma: export

#endif /* INCLUDE_KYTY_SYS_SYSSYNC_H_ */
