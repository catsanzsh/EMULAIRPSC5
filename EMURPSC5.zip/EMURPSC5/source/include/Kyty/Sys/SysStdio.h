#ifndef INCLUDE_KYTY_SYS_SYSSTDIO_H_
#define INCLUDE_KYTY_SYS_SYSSTDIO_H_

#include "Kyty/Core/Common.h"

#include "Kyty/Sys/SysLinuxStdio.h" // IWYU pragma: export
#include "Kyty/Sys/SysWindowsStdio.h" // IWYU pragma: export

#endif /* INCLUDE_KYTY_SYS_SYSSTDIO_H_ */
