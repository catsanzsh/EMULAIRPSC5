#ifndef INCLUDE_KYTY_SYS_SYSSTDLIB_H_
#define INCLUDE_KYTY_SYS_SYSSTDLIB_H_

#include "Kyty/Core/Common.h"

#include "Kyty/Sys/SysLinuxStdlib.h" // IWYU pragma: export
#include "Kyty/Sys/SysWindowsStdlib.h" // IWYU pragma: export

#endif /* INCLUDE_KYTY_SYS_SYSSTDLIB_H_ */
