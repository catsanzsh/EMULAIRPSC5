#ifndef INCLUDE_KYTY_SCRIPTS_BUILDTOOLS_H_
#define INCLUDE_KYTY_SCRIPTS_BUILDTOOLS_H_

#include "Kyty/Core/Subsystems.h"

namespace Kyty::BuildTools {

KYTY_SUBSYSTEM_DEFINE(BuildTools);

} // namespace Kyty::BuildTools

#endif /* INCLUDE_KYTY_SCRIPTS_BUILDTOOLS_H_ */
