#ifndef INCLUDE_KYTY_GAME_SDLSUBSYSTEM_H_
#define INCLUDE_KYTY_GAME_SDLSUBSYSTEM_H_

#include "Kyty/Core/Subsystems.h"

namespace Kyty::Core {

KYTY_SUBSYSTEM_DEFINE(SDL);

} // namespace Kyty::Core

#endif /* INCLUDE_KYTY_GAME_SDLSUBSYSTEM_H_ */
