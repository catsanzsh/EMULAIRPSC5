#ifndef INCLUDE_KYTY_CORE_CORE_H_
#define INCLUDE_KYTY_CORE_CORE_H_

#include "Kyty/Core/Subsystems.h"

namespace Kyty::Core {

KYTY_SUBSYSTEM_DEFINE(Core);

} // namespace Kyty::Core

#endif /* INCLUDE_KYTY_CORE_CORE_H_ */
