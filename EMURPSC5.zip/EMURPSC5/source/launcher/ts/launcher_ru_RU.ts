<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru_RU">
<context>
    <name>ConfigurationEditDialog</name>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="43"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="50"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Configuration name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="84"/>
        <source>Mount app0 to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="93"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Name of the directory where game is located&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="103"/>
        <source>Browse...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="138"/>
        <source>Screen resoultion:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="145"/>
        <source>Window resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="161"/>
        <source>Enable PS4 Pro mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="164"/>
        <source>Neo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="174"/>
        <source>Validate SPIR-V binary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="177"/>
        <source>Shader validation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="187"/>
        <source>Enable Vulkan validation layers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="190"/>
        <source>Vulkan validation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="200"/>
        <source>Dump command buffers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="203"/>
        <source>Command buffer dump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="216"/>
        <source>Enable GL_EXT_debug_printf extension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="219"/>
        <source>Spirv debug printf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="229"/>
        <source>Shader optimization type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="236"/>
        <source>Optimize shaders for code size or performance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="243"/>
        <source>Dump shaders to file or console window. If enabled may decrease emulator performance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="250"/>
        <source>Specify directory to dump shaders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="260"/>
        <source>Specify directory to dump command buffers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="270"/>
        <source>Print logs to file or console window. If enabled may decrease emulator performance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="277"/>
        <source>Specify file to dump logs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="287"/>
        <source>Enable/disable profiler. If enabled may decrease emulator performance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="294"/>
        <source>Shader log direction:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="301"/>
        <source>Shader log folder:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="308"/>
        <source>Command buffer dump folder:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="315"/>
        <source>Printf direction:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="322"/>
        <source>Printf output file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="329"/>
        <source>Profiler direction:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="336"/>
        <source>Specify file to dump profiler info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="346"/>
        <source>Profiler output file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="373"/>
        <source>Load elf:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="380"/>
        <source>Select executables to load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="408"/>
        <source>Select libraries to load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="418"/>
        <source>Load library:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="455"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="471"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="491"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_edit_dialog.ui" line="507"/>
        <source>Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ConfigurationEditDialog.cpp" line="241"/>
        <source>Save failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ConfigurationEditDialog.cpp" line="241"/>
        <source>Please fill all mandatory fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ConfigurationEditDialog.cpp" line="254"/>
        <source>Open Directory</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConfigurationListWidget</name>
    <message>
        <location filename="../forms/configuration_list_widget.ui" line="14"/>
        <source>Configurations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_list_widget.ui" line="68"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;New configuration&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_list_widget.ui" line="97"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Edit configuration&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/configuration_list_widget.ui" line="126"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Delete configuration&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ConfigurationListWidget.cpp" line="128"/>
        <source>New configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ConfigurationListWidget.cpp" line="142"/>
        <source>Edit configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ConfigurationListWidget.cpp" line="153"/>
        <source>Delete configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ConfigurationListWidget.cpp" line="153"/>
        <source>Do you want to delete configuration?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ConfigurationListWidget.cpp" line="189"/>
        <source>Run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ConfigurationListWidget.cpp" line="191"/>
        <source>New...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ConfigurationListWidget.cpp" line="192"/>
        <source>Edit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ConfigurationListWidget.cpp" line="193"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainDialog</name>
    <message>
        <location filename="../forms/main_dialog.ui" line="20"/>
        <source>Kyty Launcher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/main_dialog.ui" line="57"/>
        <location filename="../forms/main_dialog.ui" line="70"/>
        <location filename="../forms/main_dialog.ui" line="77"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/main_dialog.ui" line="86"/>
        <source>Cmd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/main_dialog.ui" line="96"/>
        <source>ConEmu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/main_dialog.ui" line="121"/>
        <source>Run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainDialog.cpp" line="271"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainDialog.cpp" line="271"/>
        <source>Can&apos;t create file:
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainDialogPrivate</name>
    <message>
        <location filename="../src/MainDialog.cpp" line="137"/>
        <source>Settings file: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainDialog.cpp" line="163"/>
        <source>Emulator: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainDialog.cpp" line="175"/>
        <source>Version: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainDialog.cpp" line="190"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainDialog.cpp" line="190"/>
        <source>Can&apos;t find emulator</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
