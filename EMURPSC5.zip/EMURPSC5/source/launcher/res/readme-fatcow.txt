﻿Free FatCow-Farm Fresh Icons
http://www.fatcow.com/free-icons

FatCow Farm-Fresh final release (3926 icons, 5 parts):
- fatcow-hosting-icons-3.9.2.zip default (10.9 Mb)
- fatcow-hosting-icons-3.9.2-color.zip (11.1 Mb)
- fatcow-hosting-icons-3.9.2-grey.zip (6.9 Mb)
- fatcow-hosting-icons-3.9.2-ico.zip (8.9 Mb)
- fatcow-hosting-icons-3.9.2-all.zip (30.7 Mb)
- fatcow-hosting-icons-3.9.2-ai-src.zip (2.82 !Gb)


Farm-Fresh v3.92, 10-04-2014
-----------------------------------------
- 126 new 32x32 and 16x16 icons added (total of 252 files)
- 139 icons renamed as per Tango Icon Theme Guidelines
- 10 new 48x48 and 96x96 Retina ready icons (added)
- Adobe Illustrator .ai vector source files (added)
- greyscale version of color icons in .png (added)
- .ico files of all .png icons files (added)
- icons sorted by 11 base colors (added)
---------------------------------------------------------------------------------

Farm-Fresh v3.80, 10-25-2013
-----------------------------------------
- 300 new 32x32 and 16x16 icons added (total of 600)
---------------------------------------------------------------------------------

Farm-Fresh v3.50, 29-03-2013
-----------------------------------------
- 500 new 32x32 and 16x16 icons added (total of 1,000)


These icons are licensed under a Creative Commons Attribution 3.0 License.
http://creativecommons.org/licenses/by/3.0/us/ if you do not know how to link
back to FatCow's website, you can ask https://plus.google.com/+MarcisGasuns
Biggest icon set drawn by a single designer (in pixel smooth style) worldwide.

We are unavailable for custom icon design work. The project is
closed (April 2014) and we do not plan to draw more metaphors.
http://twitter.com/FatCow
http://plus.google.com/+FatCow
http://www.facebook.com/FatCow

---------------------------------------------------------------------------------

© Copyright 2009-2014 FatCow Web Hosting. All rights reserved.
http://www.fatcow.com

All other trademarks and copyrights
are property of their respective owners.

---------------------------------------------------------------------------------