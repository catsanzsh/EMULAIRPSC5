src_dir = arg[1]
dst_dir = arg[2]


--print ("sync src = "..src_dir)
--print ("sync dst = "..dst_dir)

sync(src_dir, dst_dir)
