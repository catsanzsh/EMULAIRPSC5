#ifndef EMULATOR_INCLUDE_EMULATOR_EMULATOR_H_
#define EMULATOR_INCLUDE_EMULATOR_EMULATOR_H_

#include "Kyty/Core/Subsystems.h"

namespace Kyty::Emulator {

KYTY_SUBSYSTEM_DEFINE(Emulator);

} // namespace Kyty::Emulator

#endif /* EMULATOR_INCLUDE_EMULATOR_EMULATOR_H_ */
