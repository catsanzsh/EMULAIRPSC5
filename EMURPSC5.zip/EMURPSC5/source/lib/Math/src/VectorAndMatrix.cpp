#include "Kyty/Math/VectorAndMatrix.h"

//#include "Kyty/MathAll.h"

//#define VEC2_DECL
//#include "vec2_impl.h"
//#define VEC3_DECL
//#include "vec3_impl.h"
//#define VEC4_DECL
//#include "vec4_impl.h"
//#define MAT2_DECL
//#include "mat2_impl.h"
//#define MAT3_DECL
//#include "mat3_impl.h"
//#define MAT4_DECL
//#include "mat4_impl.h"

namespace Kyty::Math::m {
} // namespace Kyty::Math::m
